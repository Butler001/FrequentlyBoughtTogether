struct FBTNode{
	int BookId;
	int fbtValue;
	FBTNode* next;
};